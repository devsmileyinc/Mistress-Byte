# Mistress Byte Capacitor Project

## Steps

1. Install Node.js and Android Studio.

2. Open this folder in a terminal.

3. Install dependencies:
```bash
npm install
```

4. Add Android:
```bash
npx cap add android
```

5. Sync the web app:
```bash
npx cap sync
```

6. Open Android Studio:
```bash
npx cap open android
```

7. Build APK:
Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s)

For Google Play, build an AAB instead:
Android Studio > Build > Generate Signed Bundle / APK > Android App Bundle
