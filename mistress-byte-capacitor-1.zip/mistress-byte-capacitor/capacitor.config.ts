import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.smileyinc.mistressbyte',
  appName: 'Mistress Byte',
  webDir: 'www',
  server: {
    androidScheme: 'https'
  }
};

export default config;
